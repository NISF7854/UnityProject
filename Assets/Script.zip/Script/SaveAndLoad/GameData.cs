using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameData 
{
    //���Ǯ��
    public int currency;

    //��Ҳֿ�
    public MyDictionary<string, int> inventory;
    //��װ����Ʒ
    public List<string> equippedItems;
    public GameData()
    {
        this.currency = 0;
        inventory = new MyDictionary<string, int>();
        equippedItems = new List<string>();
    }
}
