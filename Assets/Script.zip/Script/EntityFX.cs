using System.Collections;
using Cinemachine;
using UnityEngine;

public class EntityFX : MonoBehaviour
{
    Player player;

    private SpriteRenderer sr;
    [Header("Screen Shake Fx")]
    private CinemachineImpulseSource screenShake;
    [SerializeField] private Vector3 shakePower;


    [Header("Flash FX")]
    [SerializeField] private Material hitMaterial;
    private Material originalMaterial;

    private void Start()
    {
        player = PlayerManager.instance.player;
        screenShake = GetComponent<CinemachineImpulseSource>();
        sr = GetComponentInChildren<SpriteRenderer>();
        originalMaterial = sr.material;
    }
    //��Ļ�ζ�
    public void ScreenShake(Vector3 _shakePower)
    {
        shakePower = _shakePower;
        screenShake.m_DefaultVelocity = new Vector3(0,0,0);
        screenShake.GenerateImpulse();
        screenShake.m_DefaultVelocity = new Vector3(shakePower.x * player.facingDir, shakePower.y);
        screenShake.GenerateImpulse();
    }





    private IEnumerator FlashFX()
    {
        sr.material = hitMaterial;
        yield return new WaitForSeconds(0.15f);
        sr.material = originalMaterial;
    }
}
