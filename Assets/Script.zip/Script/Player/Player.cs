using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;

public class Player : Entity
{
    public bool isBusy { private set ; get; }

    [Header("Attack Arr")]
    public Vector2[] attackArr;

    [Header("Info")]
    public float moveSpeed;
    public float jumpForce;
    public int multiJumpNum;

    public bool isMoving;
    public float x;
    public float y;

    public bool isDead = false;
    [Header("Dash Skill")]
    public float dashTimer=0f;
    [SerializeField] public float dashDuration = 1.0f;
    [SerializeField] private float dashSpeed = 20.0f;
    [SerializeField] public float dashCD = 2.0f;

    [Header("Attack")]
    //[SerializeField] private bool isAttacking = false;
    public int attackCombo = 0;
    //[SerializeField] private float comboDuration = 0.5f;
    private float comboTime;

    public bool isInvincible = false; //�޵�
    public bool isUnstoppable = false;//����
    float time = 0;
    [Header("CounterAttack")]
    public float counterAttackDuration = 0.4f;
    public bool isParrying = false;
    [SerializeField] public float parryCD = 1.0f;
    public float parryTimer=0f;

    public GameObject sword;
    public PlayerAudio playerAudio;

    [Space]
    public float wallSlideTimer=0f;

    //UI����
    [SerializeField]public UI UI;
    //�������İ�ȫλ��(��ֹ���׹��)
    public Vector2 lastSafePosition;

    public PlayerStatistic statistic {  private set ; get; }

    //����
    public SkillManager skill;
    public Machine machine { get; private set; }
    //״̬
    public PlayerIdolState idolState { get; private set; }
    public PlayerGroundedState groundedState { get; private set; }
    public PlayerMoveState moveState { get; private set; }
    public PlayerJumpState jumpState { get; private set; }  
    public PlayerAirState airState { get; private set; }    
    public PlayerDashState dashState { get; private set; }
    public PlayerWallSlideState wallSlideState { get; private set; }
    public PlayerWallJumpState wallJumpState { get; private set; } 
    public PlayerPrimaryAttackState primaryAttackState { get; private set; }
    public PlayerCounterAttackState counterAttackState { get; private set; }
    public PlayerAimSwordState aimSwordState { get; private set; }
    public PlayerCatchSwordState catchSwordState { get; private set; }
    public PlayerBlackHoleState blackHoleState { get; private set; }
    public PlayerDeadState deadState { get; private set; }

    public PlayerStunnedState stunnedState { get; private set; }

    public PlayerFallingState fallingState { get; private set; }    
    protected override void Awake()
    {
        base.Awake();
        skill = SkillManager.instance;
        statistic = GetComponent<PlayerStatistic>();
        playerAudio = GetComponentInChildren<PlayerAudio>();

        machine = new Machine();
        moveState = new PlayerMoveState(machine, this, "Move");
        idolState = new PlayerIdolState(machine, this, "Idol");
        groundedState = new PlayerGroundedState(machine, this, "");
        jumpState = new PlayerJumpState(machine, this, "Jump");
        airState = new PlayerAirState(machine, this, "Jump");
        dashState = new PlayerDashState(machine, this, "Dash");
        wallSlideState = new PlayerWallSlideState(machine, this, "WallSlide");
        wallJumpState = new PlayerWallJumpState(machine, this, "Jump");
        primaryAttackState = new PlayerPrimaryAttackState(machine, this, "Attack");
        counterAttackState = new PlayerCounterAttackState(machine, this, "CounterAttack");
        aimSwordState = new PlayerAimSwordState(machine, this, "AimSword");
        catchSwordState = new PlayerCatchSwordState(machine, this, "CatchSword");
        blackHoleState = new PlayerBlackHoleState(machine, this, "BlackHole");
        deadState = new PlayerDeadState(machine, this, "Dead");
        fallingState = new PlayerFallingState(machine, this, "Falling");
        stunnedState = new PlayerStunnedState(machine, this, "Stunned");
    }

    // Start is called before the first frame update
    protected override void Start()
    {
        InvokeRepeating("GetSafePosition", 0f, 3f);



        base.Start();
        machine.Initialize(idolState);

    }

    // Update is called once per frame
    protected override void Update()
    {
        //��ͣ��Ϸֹͣ������ж���
        if(Time.timeScale == 0) return;

        


        //
        x = rb.velocity.x; y=rb.velocity.y;

        //����״̬��
        machine.Update();
        base.Update();

        //�����ǽ����������bug
        if (wallSlideTimer>0)
        {
            wallSlideTimer -= Time.deltaTime;
        }
        //���CD
        if(dashTimer>0)
        {
            dashTimer -= Time.deltaTime;
        }
        //����CD
        if(parryTimer>0)
        {
            parryTimer -= Time.deltaTime;
        }
        //ͬ��AttackComb
        attackCombo = primaryAttackState.comboCounter;
        //ʹ��ҩˮ
        if(Input.GetKeyDown (KeyCode.Alpha1))
        {
            Inventory.Instance.UseFlask();
        }
        //�޵�Ƶ��FX
        FlickeringFX();
    }

    public void AssignMewSword(GameObject newSword)
    {
        sword = newSword;
    }
    public void AssignMewSword()
    {
        Destroy(sword);
    }


    //�����ɹ�
    public bool CheckParrySuccessfully()
    {
        if (isParrying)
        {
            isParrying = false;
            
            ani.SetBool("SuccessfullyCounter", true);
            machine.currentState.stateTimer = 10.0f;
            return true;
        }
        return false;
    }
    //Я��
    public IEnumerator BusyFor(float value)
    {
        isBusy = true;
        yield return new WaitForSeconds(value);
        isBusy=false;
    }

    //ˮƽ�ƶ�
    public void Move(float value)
    {
        //ˮƽ�ƶ�
        rb.velocity = new Vector2(value * moveSpeed, rb.velocity.y);
        FilpController();
    }
    //��Ծ
    public void Jump()
    {
        rb.velocity = new Vector2(rb.velocity.x, jumpForce);
    }
    //��̼���
    public void Dash()
    {
        rb.velocity = new Vector2(facingDir * dashSpeed, 0);
       
    }
  
    //�������Źؼ�֡�ű�
    public void AnimationTrigger()
    {
        machine.currentState.AnimationFinishTrigger();
    }
    //�ܻ�ѣ��
    public void BeStunned(Vector2 _direction)
    {
        if(_direction.x < transform.position.x)
        {
            this.SetVelocity(2f, 5f);
        }
        else
        {
            this.SetVelocity(-2f, 5f);
        }
        //�ܻ��޵�
        StartCoroutine(GiveInvincible(1.8f));
        machine.ChangeState(stunnedState);
    }
    //�ܻ��޵�
    public IEnumerator GiveInvincible(float _time)
    {
        this.isInvincible = true;

        yield return new WaitForSeconds(_time);

        isInvincible = false;

    }
    //�ܻ�Ƶ��FX
    private void FlickeringFX()
    {
        
        if(isInvincible)
        {
            
            time += Time.deltaTime; 
            if(time >= 0.1f)//������
            {
                if(sr.color.a != 0)
                {
                    sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 0);
                }
                else if(sr.color.a == 0)
                {
                    sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 255);
                }
                time = 0;
            }
        }
        if(!isInvincible) 
        {
            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 255);
        }
    }
    //ÿ��3���¼һ�����λ��
    private void GetSafePosition()
    {
        //��¼������һ����ƽ̨��λ��
        if (isGrounded)
        {
            lastSafePosition = transform.position;
        }
    }
    //����ʱ��
    public IEnumerator SlowDownTime(float _scale,float _time)
    {
        Time.timeScale = _scale;

        yield return new WaitForSeconds(_time);

        Time.timeScale = 1f;

    }

}
    

