using System.Collections;
using System.Collections.Generic;
using System.Data;
using UnityEngine;

public class PlayerAnimEven : MonoBehaviour
{
    private Player player;


    // Start is called before the first frame update
    void Start()
    {
        player = GetComponentInParent<Player>();
    }
    //������������֡
    private void AnimationTrigger()
    {
        player.AnimationTrigger();
    }
    //������Ч֡
    private void AttackTrigger()
    {
        //ʩ�������������(���й���ʱ)
        if (Inventory.Instance.GetEquipmentDataByType(EquipmentType.Weapon) != null)
        {
            Inventory.Instance.GetEquipmentDataByType(EquipmentType.Weapon).ExecuteAllEffectsWhenAttack();
        }

        Collider2D[] colliders = Physics2D.OverlapCircleAll(player.attackCheck.transform.position, player.attackRadius);
        foreach(var hit in colliders)
        {
            if(hit.GetComponent<Enemy>() != null)
            {
                //��������ʱֱ�ӷ���
                if(hit.GetComponent<Enemy>().isDead == true)
                {
                    return;
                }

                Enemy enemy = hit.GetComponent<Enemy>();
                //����������Ч
                player.playerAudio.PlaySFX(11);
                player.statistic.DoDamage(enemy.statistic);;
                //ʩ�������������(���е���ʱ)
                if(Inventory.Instance.GetEquipmentDataByType(EquipmentType.Weapon) != null)
                {
                    Inventory.Instance.GetEquipmentDataByType(EquipmentType.Weapon).ExecuteAllEffectsWhenHIt(enemy);
                }
                
            }
        }
    }
    //������������֡
    private void FinishSuccessfullyCounterAttack()
    {
        player.AnimationTrigger();
    }

    //�ɽ�
    private void ThrowSwordTrigger()
    {
        player.skill.sword.CreateSword();
    }
}