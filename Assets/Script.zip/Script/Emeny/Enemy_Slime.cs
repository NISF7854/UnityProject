using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Slime : Enemy
{
  

    //״̬
    public SlimeGroundState groundState;
    public SlimeIdleState idleState;
    public SlimeMoveState moveState;
    public SlimeClashState clashState;
    public bool isClashing = false;

    public SlimeStunnedState stunnedState;
    public SlimeDeadState deadState;
    protected override void Awake()
    {
        base.Awake();
        //�޸ĳ�ʼ����������
        facingDir = -1;
        isFacingRight = false;

        //��ʼ��״̬
        idleState = new SlimeIdleState(this, this,machine, "Idle");
        moveState = new SlimeMoveState(this, this, machine, "Move");
        clashState = new SlimeClashState(this, this, machine, "Clash");
        stunnedState = new SlimeStunnedState(this, this, machine, "Stunned");
        deadState = new SlimeDeadState(this, this, machine, "Dead");
    }

    protected override void Start()
    {
        base.Start();

        machine.Initialize(idleState);

        //������ײ�빥�����뾶����һ��
        attackCheck.GetComponent<CapsuleCollider2D>().size = new Vector2(attackRadius, attackRadius);
    }

    protected override void Update()
    {
        base.Update();
    }



    protected override void OnDrawGizmos()
    {
        base.OnDrawGizmos();
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(new Vector3(wallCheck.transform.position.x, wallCheck.transform.position.y - 0.1f), new Vector3
            (wallCheck.transform.position.x + sightDistance * facingDir, wallCheck.transform.position.y - 0.1f));
        Gizmos.color = Color.red;
        Gizmos.DrawLine(new Vector3(wallCheck.transform.position.x, wallCheck.transform.position.y - 0.2f), new Vector3
            (wallCheck.transform.position.x + attackDistance * facingDir, wallCheck.transform.position.y - 0.2f));
    }

    //��ѣ��
    public override void BeStunned(Vector2 _attacker, float _stateTime, Vector2 _direction)
    {
        base.BeStunned(_attacker, _stateTime, _direction);
        machine.ChangeState(stunnedState);
    }



}
