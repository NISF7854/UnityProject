using System.Text;
using UnityEditor;
using UnityEngine;

public enum EquipmentType
{
    Weapon,
    Armor,
    Amulet,
    Flask
}

[CreateAssetMenu(fileName = "New Item Data",menuName ="Data/Equipment")]
public class ItemData_Equipment : ItemData
{
    public EquipmentType equipmentType;//��������
    public ItemEffect[] itemEffects;//����
    public string effectDescription;
    


    [Header("Attack")]
    public float strength;//������
    public float criticalRate;//������
    public float criticalPower;//�����˺�

    public float magic;//����ǿ��

    [Header("Resistance")]
    public float armor;//����
    public float magicResistance;//ħ��

    [Header("Health")]
    public float maxHealth;//�������ֵ

    [Header("Magic State")]
    public float fireDamage;//����
    public float iceDamage;//����
    public float lightningDamage;//����

    //������������
    public void AddModifiers()
    {
        PlayerStatistic playerStatistic = PlayerManager.instance.player.statistic;

        playerStatistic.strength.AddModifier(strength, ModifierType.Add);
        playerStatistic.criticalRate.AddModifier(criticalRate, ModifierType.Add);
        playerStatistic.criticalPower.AddModifier(criticalPower, ModifierType.Add   );
        playerStatistic.magic.AddModifier(magic, ModifierType.Add);
        playerStatistic.armor.AddModifier(armor, ModifierType.Add);
        playerStatistic.magicResistance.AddModifier(magicResistance , ModifierType.Add);
        playerStatistic.maxHealth.AddModifier(maxHealth, ModifierType.Add);
        playerStatistic.fireDamage.AddModifier(fireDamage, ModifierType.Add);
        playerStatistic.iceDamage.AddModifier(iceDamage, ModifierType.Add);
        playerStatistic.lightningDamage.AddModifier(lightningDamage, ModifierType.Add);
    }
    public void RemoveModifiers() 
    {
        PlayerStatistic playerStatistic = PlayerManager.instance.player.statistic;

        playerStatistic.strength.RemoveModifier(strength,ModifierType.Add);
        playerStatistic.criticalRate.RemoveModifier(criticalRate, ModifierType.Add);
        playerStatistic.criticalPower.RemoveModifier(criticalPower, ModifierType.Add);
        playerStatistic.magic.RemoveModifier(magic, ModifierType.Add);
        playerStatistic.armor.RemoveModifier(armor, ModifierType.Add);
        playerStatistic.magicResistance.RemoveModifier(magicResistance, ModifierType.Add);
        playerStatistic.maxHealth.RemoveModifier(maxHealth, ModifierType.Add);
        playerStatistic.fireDamage.RemoveModifier(fireDamage, ModifierType.Add);
        playerStatistic.iceDamage.RemoveModifier(iceDamage, ModifierType.Add);
        playerStatistic.lightningDamage.RemoveModifier(lightningDamage, ModifierType.Add);
    }
    //ִ�д���Ч��
    public void ExecuteAllEffectsWhenHIt(Enemy _target)
    { 
        foreach(var effect in itemEffects)
        {
            effect.ExecuteEffectWhenHit(_target);
        }
    }
    public void ExecuteAllEffectsWhenAttack()
    {
        foreach (var effect in itemEffects)
        {
            effect.ExecuteEffectWhenAttack();
        }

    }
    public void ExecuteAllEffectsWhenActive()
    {
        foreach (var effect in itemEffects)
        {
            effect.ExecuteEffectWhenActive();
        }
    }
    public void ExecuteAllEffectsWhenBeHit(Enemy _target)
    {
        foreach (var effect in itemEffects)
        {
            effect.ExecuteEffectWhenBeHit(_target);
        }
    }

    //
    public string GetStatisticText()
    {
        StringBuilder stb = new StringBuilder();
        if(strength > 0)
        {
            stb.Append("+ "+strength.ToString()+ " ������ ");
            stb.AppendLine();
        }
        if (magic > 0)
        {
            stb.Append("+ " + magic.ToString() + " ��ǿ ");
            stb.AppendLine();
        }
        if (criticalRate > 0)
        {
            stb.Append("+ " + criticalRate.ToString() + " ������ ");
            stb.AppendLine();
        }
        if (criticalPower > 0)
        {
            stb.Append("+ " + criticalPower.ToString() + " �����˺� ");
            stb.AppendLine();
        }
        if (armor > 0)
        {
            stb.Append("+ " + armor.ToString() + " ���� ");
            stb.AppendLine();
        }
        if (magicResistance > 0)
        {
            stb.Append("+ " + magicResistance.ToString() + " ħ�� ");
            stb.AppendLine();
        }
        if (maxHealth > 0)
        {
            stb.Append("+ " + maxHealth.ToString() + " ����ֵ ");
        }

        return stb.ToString();
    }

    

}


